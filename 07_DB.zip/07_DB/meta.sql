ZZZZZZZZZZZZZZZZZZZZZZZ


drop table customer_data;

create table customer_data(Case_Owner VARCHAR(50),	Incident_Number INT,	Teams VARCHAR(50),	Case_Closed_By VARCHAR(50),	
				   Geo VARCHAR(10),	Response_Time_of_Agent TIME,	T_Time TIME,	T_Start_Date Date,	T_End_Date Date,	
				   Chat_Duration TIME,	Customer_Rating INT,	Transferred_Chat VARCHAR(10),	Customer_Wait_Time TIME,	
				   Ip_Address INET, Aknowledge VARCHAR(10));
				   
select * from customer_data;

SET client_encoding = 'ISO_8859_5';

COPY customer_data(Case_Owner,	Incident_Number,Teams,Case_Closed_By,
				   Geo,	Response_Time_of_Agent,	T_Time,	T_Start_Date,	T_End_Date,	
				   Chat_Duration,	Customer_Rating,	Transferred_Chat,	Customer_Wait_Time,	
				   Ip_Address, 	Aknowledge)				   
FROM 'E:Case3.csv'
DELIMITER ','
CSV HEADER;

select * from customer_data limit 100;


SELECT rolname, rolpassword FROM pg_authid;


select count(Incident_Number) as Cnt, Case_Owner from customer_data group by Case_Owner HAVING COUNT(*) > 150 Order by Cnt DESC limit 25;


XXXXXXXXXXXZZZZZZZZZ
drop table customer_data;

select * from customer_data limit 100;

create table customer_data(Case_Owner VARCHAR(50),	Incident_Number INT,	Teams VARCHAR(50),	Case_Closed_By VARCHAR(50),	
				   Geo VARCHAR(10),	Response_Time_of_Agent INT,	T_Time TIME,	T_Start_Date Date,	T_End_Date Date,	
				   Chat_Duration TIME,	Customer_Rating INT,	Transferred_Chat VARCHAR(10),	Customer_Wait_Time TIME,	
				   Ip_Address INET, Aknowledge VARCHAR(10));

COPY customer_data(Case_Owner,	Incident_Number,Teams,Case_Closed_By,
				   Geo,	Response_Time_of_Agent,	T_Time,	T_Start_Date,	T_End_Date,	
				   Chat_Duration,	Customer_Rating,	Transferred_Chat,	Customer_Wait_Time,	
				   Ip_Address, 	Aknowledge)				   
FROM 'E:Case3.csv'
DELIMITER ','
CSV HEADER;

select count(Incident_Number) as Cnt, Case_Owner from customer_data group by Case_Owner HAVING COUNT(*) > 150 
Order by Cnt DESC limit 25; 


select count(Incident_Number) as Cnt from customer_data;



select Case_Owner, sum(Response_Time_of_Agent),  count(Incident_Number) as tic from customer_data group by Case_Owner order by tic limit 25;


select Case_Owner, sum(Response_Time_of_Agent),  count(Incident_Number) as tic from customer_data group by Case_Owner order by tic desc limit 25;

select Case_Owner, sum(Response_Time_of_Agent)/60,  count(Incident_Number) as tic 
from customer_data group by Case_Owner order by tic limit 25;

Select Aknowledge, Count(Aknowledge) from customer_data group by Aknowledge;
Select Transferred_Chat, count(Transferred_Chat) from customer_data group by Transferred_Chat;

ZZZZZZZZZZZZZZZZZZZZZZZ

Total no of tickets handeled vs Case Owners

Total_no_of_Minutes_vs_Incident_Tickets
Total_no._of_Minutes
Incident_Tickets

Sum_Of_Minutes_to_Acknowledge_and_No._of_Incidents